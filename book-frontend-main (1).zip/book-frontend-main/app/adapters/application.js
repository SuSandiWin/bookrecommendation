import RESTAdapter from "@ember-data/adapter/rest";
import { inject as service } from '@ember/service';
import TokenAdapterMixin from 'ember-simple-auth-token/mixins/token-adapter';

import ENV from '../config/environment';
if (ENV.environment === 'development') {
  var host = ENV.localHost
} else if (ENV.environment === 'production') {
  var host = ENV.remoteHost
}


export default class ApplicationAdapter extends RESTAdapter.extend(TokenAdapterMixin) {
  host = host;
  @service session;

}
