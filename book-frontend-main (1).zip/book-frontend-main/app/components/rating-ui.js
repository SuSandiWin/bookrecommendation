

import Component from '@glimmer/component';
import { inject as service } from "@ember/service";
import {
  action, computed
} from '@ember/object';
import {
  tracked
} from '@glimmer/tracking';
export default class RatingUiComponent extends Component {
  @tracked profile;
  @service fetch_api;
  constructor() {
    super(...arguments);
    this.args.getRating()
  }


}
