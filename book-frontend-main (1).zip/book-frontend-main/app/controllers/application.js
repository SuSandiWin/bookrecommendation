import Controller from '@ember/controller';
import { inject as service } from '@ember/service';
import { action, computed } from '@ember/object';

export default class ApplicationController extends Controller {
  @service router;

  get currentRouteName() {
    return this.router.currentRouteName;
  }
  @action
  invalidateSession() {
    this.session.invalidate();
  }

  @action
  goToHome() {
    this.transitionToRoute('home');
  }

  @action
  goToProfile() {
    this.transitionToRoute('profile');
  }

  @action
  goToRecom()
  {
    this.transitionToRoute('recom');
  }


}
