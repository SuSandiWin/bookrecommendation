
import Controller from '@ember/controller';
import { inject as service } from '@ember/service';
import { action, computed } from '@ember/object';
import {
  tracked
} from '@glimmer/tracking';
import ENV from '../config/environment';
if (ENV.environment === 'development') {
  var host = ENV.localHost
} else if (ENV.environment === 'production') {
  var host = ENV.remoteHost
}
export default class BookDetailController extends Controller {
  @service  fetch_api;
  @service session;
  @tracked rating;
  @action
  async updateRating(rate) {
    var _that = this;
    var token = _that.session.session.content.authenticated.access_token;

    var data = { "book_id": this.model.id, "rating": rate }
    const response = await _that.fetch_api.postData(`${host}/add_review`,data, token).then(data => {
      var payload = {}
      _that.rating = data["rating"]
    })
  }

  @action
  async getRating() {
    var _that = this;
    var token = _that.session.session.content.authenticated.access_token;
    const response = await _that.fetch_api.fetchData(`${host}/get_review/${this.model.id}`, token).then(data => {
      _that.rating = data["rating"];
    })
  }

  @action
  backToHome() {

    if(this.rating <1)
      {
      if (confirm('Please add rating !')) {
        // Save it!

      } else {
        // Do nothing!
        this.transitionToRoute("home")

      }
      }
      else{
      this.transitionToRoute("home")
    }
  }
}
