import Controller from '@ember/controller';

export default class HomeController extends Controller {}
