import Controller from '@ember/controller';
import { inject as service } from '@ember/service';
import { action, computed } from '@ember/object';
import { tracked } from '@glimmer/tracking';
export default class LoginController extends Controller {
  @service session;
  @tracked username;
  @tracked password;
  @tracked error_msg;

  @action
  async authenticate(e) {
    var _that = this;
    this.error_msg = '';
    e.preventDefault();
    const credentials = { username: this.username, password: this.password };
    const authenticator = 'authenticator:jwt';
    console.log(credentials);
    this.session
      .authenticate(authenticator, credentials)
      .then(function functionName(data) {
        _that.transitionToRoute('home');
      })
      .catch((e) => {
        console.log(e.json.detail);

        _that.error_msg = e.json.detail;
      });
  }
}
