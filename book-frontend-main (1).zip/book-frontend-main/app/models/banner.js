import Model, { attr } from "@ember-data/model";
import ENV from '../config/environment';
if (ENV.environment === 'development') {
  var host = ENV.localHost
} else if (ENV.environment === 'production') {
  var host = ENV.remoteHost
}
export default class BannerModel extends Model {
  @attr("string") title;
  @attr("string") description;
  @attr("string") createdate;
  @attr postImage;

  get getPostImage() {

    console.log(this.postImage)
    try { return host + "/" + this.postImage; }
    catch (err) {
      return "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"
    }
  }
}
