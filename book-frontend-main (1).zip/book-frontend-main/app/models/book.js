
import Model, { attr } from "@ember-data/model";
import ENV from '../config/environment';
if (ENV.environment === 'development') {
  var host = ENV.localHost
} else if (ENV.environment === 'production') {
  var host = ENV.remoteHost
}
export default class BookModel extends Model {
  @attr("string") name;
  @attr("string") category;
  @attr("string") createdate;
  @attr("string") description;
  @attr("string") ebook;
  @attr postImage;

  get getPostImage() {

    console.log(this.postImage)
    try { return host + "/" + this.postImage; }
    catch (err) {
      return "https://images.secretlab.co/theme/common/collab_pokemon_catalog_charizard-min.png"
    }
  }

  get getEbook() {

    console.log(this.ebook)
    try { return host + "/" + this.ebook; }
    catch (err) {
      return "https://images.secretlab.co/theme/common/collab_pokemon_catalog_charizard-min.png"
    }
  }
}
