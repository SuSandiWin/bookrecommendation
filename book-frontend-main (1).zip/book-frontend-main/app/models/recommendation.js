

import Model, { attr } from "@ember-data/model";
import ENV from '../config/environment';
if (ENV.environment === 'development') {
  var host = ENV.localHost
} else if (ENV.environment === 'production') {
  var host = ENV.remoteHost
}
export default class RecommendationModel extends Model {
  @attr("string") name;
  @attr("string") category;
  @attr("string") createdate;
  @attr("string") description;
  @attr postImage;

  get getPostImage() {

    console.log(this.postImage)
    try { return host + "/" + this.postImage; }
    catch (err) {
      return "https://images.secretlab.co/theme/common/collab_pokemon_catalog_charizard-min.png"
    }
  }
}
