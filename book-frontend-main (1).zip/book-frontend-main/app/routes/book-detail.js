import Route from '@ember/routing/route';

export default class BookDetailRoute extends Route {
  model(params)
  {
    this.store.unloadAll("book")
    return this.store.findRecord("book",params["id"])
  }
}
