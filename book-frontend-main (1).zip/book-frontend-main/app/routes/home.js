import Route from '@ember/routing/route';
import RSVP from 'rsvp';
import RouteMixin from 'ember-cli-pagination/remote/route-mixin';
import { inject as service } from '@ember/service';
import AuthenticatedRouteMixin from 'ember-simple-auth/mixins/authenticated-route-mixin';
export default class HomeRoute extends Route.extend(AuthenticatedRouteMixin, RouteMixin) {
  @service infinity;

  model(params) {
    this.store.unloadAll("banner")
    return RSVP.hash({
      banner: this.store.findAll("banner"),
      model: this.infinity.model('book', params),


    });
  }

  setupController(controller, models) {

    controller.setProperties(models);
  }
}


