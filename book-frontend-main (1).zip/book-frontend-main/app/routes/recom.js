

import Route from '@ember/routing/route';
import RSVP from 'rsvp';
import RouteMixin from 'ember-cli-pagination/remote/route-mixin';
import { inject as service } from '@ember/service';
import AuthenticatedRouteMixin from 'ember-simple-auth/mixins/authenticated-route-mixin';
export default class RecomRoute extends Route.extend(AuthenticatedRouteMixin) {


  model(params) {
    return this.store.findAll('recommendation');
  }
}





