import Service from '@ember/service';
import fetch from 'fetch';

export default class FetchApiService extends Service {
  async fetchData(url, bearerToken) {
    try {
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${bearerToken}`,
        },
      });

      if (!response.ok) {
        // Handle the error response here
        throw new Error(`POST request failed with status: ${response.status}`);
      }

      // Handle the successful response here, e.g., return data
      return response.json();
    } catch (error) {
      // Handle any network or fetch errors here
      console.error('Error:', error);
      throw error;
    }
  }

  async postData(url, data, bearerToken) {
    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${bearerToken}`, // Add the Bearer token header
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        // Handle the error response here
        throw new Error(`POST request failed with status: ${response.status}`);
      }

      // Handle the successful response here, e.g., return data
      return response.json();
    } catch (error) {
      // Handle any network or fetch errors here
      console.error('Error:', error);
      throw error;
    }
  }

}
